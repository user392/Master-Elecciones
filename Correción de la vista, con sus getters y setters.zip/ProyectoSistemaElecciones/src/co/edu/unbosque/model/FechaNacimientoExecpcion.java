package co.edu.unbosque.model;

public class FechaNacimientoExecpcion extends Exception {

	public FechaNacimientoExecpcion() {

		super();
	}

	public FechaNacimientoExecpcion(String m) {

		super(m);
	}
}
