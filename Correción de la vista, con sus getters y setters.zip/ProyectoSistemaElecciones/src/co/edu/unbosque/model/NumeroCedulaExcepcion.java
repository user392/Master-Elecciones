package co.edu.unbosque.model;

public class NumeroCedulaExcepcion extends Exception {

	public NumeroCedulaExcepcion() {

		super();

	}

	public NumeroCedulaExcepcion(String s) {

		super(s);

	}
}
