package co.edu.unbosque.view;

import java.awt.Color;
import java.awt.Image;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class VtnPrincipal extends JFrame
{
	private PnlAddPer pnlAddPer;
	private PnlBuscarPer pnlBuscarPer;
	private PnlGraficas pnlGraficas;
	private PnlInicio pnlInicio;
	private PnlGrfHommuj pnlGrfHommuj;
	private PnlListaInscritos pnlListaInscritos;
	
	
	
	public VtnPrincipal()
	{
		setLayout(null);
		setSize(900,540);
		setBackground(Color.black);
		setTitle("SISTEMA REGISTRADURIA");
		getContentPane().setLayout(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		IniciarComponentes();
		
		setLocationRelativeTo(null);
		setVisible(true);
	}
	
	public void IniciarComponentes()
	{
		setPnlInicio(new PnlInicio());
		getPnlInicio().setLocation(0, 0);
		getPnlInicio().setSize(886, 503);
		add(getPnlInicio());
		
		
		setPnlAddPer(new PnlAddPer());
		getPnlAddPer().setLocation(0, 0);
		getPnlAddPer().setSize(886, 503);
		add(getPnlAddPer());
		
		setPnlBuscarPer(new PnlBuscarPer());
		getPnlBuscarPer().setLocation(0, 0);
		getPnlBuscarPer().setSize(886, 503);
		add(getPnlBuscarPer());
		
		setPnlGraficas(new PnlGraficas());
		getPnlGraficas().setSize(886, 503);
		getPnlGraficas().setLocation(0, 0);
		add(getPnlGraficas());
		
		setPnlListaInscritos(new PnlListaInscritos());
		getPnlListaInscritos().setSize(886, 503);
		getPnlListaInscritos().setLocation(0, 0);
		add(getPnlListaInscritos());
		
		
		
		
		setPnlGrfHommuj(new PnlGrfHommuj());
		getPnlGrfHommuj().setSize(886, 506);
		getPnlGrfHommuj().setLocation(0, 0);
		add(getPnlGrfHommuj());
		
	}

	public PnlAddPer getPnlAddPer() {
		return pnlAddPer;
	}

	public void setPnlAddPer(PnlAddPer pnlAddPer) {
		this.pnlAddPer = pnlAddPer;
	}

	public PnlBuscarPer getPnlBuscarPer() {
		return pnlBuscarPer;
	}

	public void setPnlBuscarPer(PnlBuscarPer pnlBuscarPer) {
		this.pnlBuscarPer = pnlBuscarPer;
	}

	public PnlGraficas getPnlGraficas() {
		return pnlGraficas;
	}

	public void setPnlGraficas(PnlGraficas pnlGraficas) {
		this.pnlGraficas = pnlGraficas;
	}

	public PnlInicio getPnlInicio() {
		return pnlInicio;
	}

	public void setPnlInicio(PnlInicio pnlInicio) {
		this.pnlInicio = pnlInicio;
	}

	public PnlGrfHommuj getPnlGrfHommuj() {
		return pnlGrfHommuj;
	}

	public void setPnlGrfHommuj(PnlGrfHommuj pnlGrfHommuj) {
		this.pnlGrfHommuj = pnlGrfHommuj;
	}

	public PnlListaInscritos getPnlListaInscritos() {
		return pnlListaInscritos;
	}

	public void setPnlListaInscritos(PnlListaInscritos pnlListaInscritos) {
		this.pnlListaInscritos = pnlListaInscritos;
	}

	
}
